from operatoros.api_fetcher import APIFetcher

def save_top_niches(niches):
    # stub: just return the top 5 scored niches
    top = sorted(niches, key=lambda x: x.get("score", 0), reverse=True)[:5]
    return top

if __name__ == "__main__":
    fetcher = APIFetcher()
    trends = fetcher.fetch_trends()
    financials = fetcher.fetch_financials()
    scored = fetcher.score_niches(financials, mock=True)
    top_niches = save_top_niches(scored)
    print("Top 5 Niches by Revenue & Trend Score:\n")
    for i, niche in enumerate(top_niches, 1):
        print(f"{i}. {niche['name']} (Score: {niche['score']})")

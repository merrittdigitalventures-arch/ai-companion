import os
import tkinter as tk
from tkinter import simpledialog, messagebox, ttk
from operatoros.api_fetcher import APIFetcher
from operatoros.bundle_generator import generate_bundle
from operatoros.state import save_current_niche
from dotenv import load_dotenv, set_key

load_dotenv()  # Load existing .env

# Helper to ensure API keys
def get_api_key(name, friendly_name, instructions):
    value = os.getenv(name)
    if not value:
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo(f"{friendly_name} Needed", instructions)
        value = simpledialog.askstring(f"{friendly_name} Key", f"Enter {friendly_name}:")
        if value:
            set_key(".env", name, value)
        root.destroy()
    return value

# Required API keys
TWITTER = get_api_key(
    "TWITTER_BEARER_TOKEN",
    "Twitter Bearer Token",
    "Go to https://developer.twitter.com/en/portal/projects to create an app and get your token."
)

STRIPE = get_api_key(
    "STRIPE_API_KEY",
    "Stripe API Key",
    "Login to Stripe, go to Developers → API Keys → Copy the Publishable key."
)

GUMROAD = get_api_key(
    "GUMROAD_ACCESS_TOKEN",
    "Gumroad Access Token",
    "Login to Gumroad → Settings → Advanced → Generate Access Token."
)

# Optional APIs (can add more)
# Example:
# PAYPAL = get_api_key("PAYPAL_CLIENT_ID", "PayPal Client ID", "Instructions here...")

# Fetch & score niches
fetcher = APIFetcher()
niches = fetcher.fetch_trends()
niches = fetcher.score_niches(fetcher.fetch_financials(), mock=False)

# GUI for niche selection
root = tk.Tk()
root.title("OperatorOS: Choose Your Niche")

tk.Label(root, text="Select a Niche to Produce").pack(pady=5)

niche_var = tk.StringVar()
niche_listbox = tk.Listbox(root, listvariable=niche_var, height=10, width=50)
for n in niches:
    niche_listbox.insert(tk.END, f"{n['name']} (Score: {n.get('score',0)})")
niche_listbox.pack(pady=5)

def choose_niche():
    selection = niche_listbox.curselection()
    if not selection:
        messagebox.showwarning("Select Niche", "Please select a niche to continue.")
        return
    chosen = niches[selection[0]]
    save_current_niche(chosen)
    messagebox.showinfo("Niche Selected", f"You selected: {chosen['name']}")
    root.destroy()
    # Generate bundle
    generate_bundle(chosen)
    messagebox.showinfo("Done", f"Bundle for {chosen['name']} generated and saved.")

ttk.Button(root, text="Select Niche and Generate Bundle", command=choose_niche).pack(pady=10)

root.mainloop()
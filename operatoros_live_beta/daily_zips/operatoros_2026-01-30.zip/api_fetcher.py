import requests
from operatoros.logger import log_run

class APIFetcher:
    def __init__(self):
        pass  # any initialization

    def fetch_trends(self):
        # placeholder: replace with Twitter/IG scraping later
        return [{"name": "AI Prompt Packs"}, {"name": "Local Lead Gen"}]

    def fetch_financials(self):
        # placeholder: replace with Stripe/Gumroad API later
        return [{"name": "AI Prompt Packs", "revenue": 1000},
                {"name": "Local Lead Gen", "revenue": 800}]

    def score_niches(self, niche_list, mock=False):
        if mock:
            for niche in niche_list:
                niche["score"] = 50  # default test score
            return niche_list
        # live scoring (replace with real API calls)
        for niche in niche_list:
            niche["score"] = niche.get("revenue", 0)  # simple revenue-based score
        return niche_list

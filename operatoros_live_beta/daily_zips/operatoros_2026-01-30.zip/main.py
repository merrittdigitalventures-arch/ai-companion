from operatoros import bundle_generator

def run():
    print("\n--- Launching OperatorOS GUI ---")
    print("API credentials entry and niche selection must occur first.\n")

    chosen_niche = None  # This will be set ONLY after real API scoring

    if chosen_niche is None:
        print("OperatorOS halted: No niche selected.")
        print("Run API setup and real niche scoring before continuing.\n")
        return

    bundle = bundle_generator.generate_bundle(chosen_niche)
    print("Bundle generated:", bundle)

if __name__ == "__main__":
    run()
